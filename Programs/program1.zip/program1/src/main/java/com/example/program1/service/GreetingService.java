package com.example.program1.service;

public interface GreetingService { 
String greet(); 
}
