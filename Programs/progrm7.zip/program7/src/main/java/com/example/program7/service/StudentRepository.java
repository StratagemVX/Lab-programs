package com.example.program7.service;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.program7.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {

}