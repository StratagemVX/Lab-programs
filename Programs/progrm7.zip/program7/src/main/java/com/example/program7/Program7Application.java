package com.example.program7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Program7Application {

	public static void main(String[] args) {
		SpringApplication.run(Program7Application.class, args);
	}

}
