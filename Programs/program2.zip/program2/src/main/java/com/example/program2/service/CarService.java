package com.example.program2.service;

public interface CarService { 
void startCar(); 
}
