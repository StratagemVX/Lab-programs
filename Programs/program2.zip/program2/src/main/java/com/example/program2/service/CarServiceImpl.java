package com.example.program2.service;

import org.springframework.stereotype.Service;

@Service 
public class CarServiceImpl implements CarService { 
@Override 
public void startCar() { 
 
} 
public static void main(String[] args) { 

System.out.println("Car is starting..."); 
} 
}