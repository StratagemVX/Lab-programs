package com.example.program2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.program2.service.CarService;

@RestController 
public class CarController { 
private final CarService carService; 
@Autowired 
public CarController(CarService carService) { 
this.carService = carService; 
} 
@GetMapping("/start") 
public String startCar() { 
carService.startCar(); 
return "Car started!"; 
} 
} 