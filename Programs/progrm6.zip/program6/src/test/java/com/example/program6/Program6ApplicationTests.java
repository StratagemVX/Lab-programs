package com.example.program6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Program6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
