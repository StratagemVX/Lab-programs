package com.example.program6;

import com.example.program6.entity.Student1;
import com.example.program6.entity.StudentManager;

public class Main {
    public static void main(String[] args) {

        StudentManager manager = new StudentManager();

        // Insert
        Student1 stud = new Student1();
        stud.setId(21);
        stud.setName("Guru");
        stud.setAge(26);
        manager.insertStudent(stud);

        // Fetch
        Student1 s = manager.searchStudentById(15);
        if (s != null) {
            System.out.println("Name: " + s.getName() + " Age: " + s.getAge());
        }

        // Update
        manager.updateStudentAge(16, 22);

        // Delete
        manager.deleteStudent(15);
    }
}