package com.example.program6.entity;

import org.hibernate.Session;
import com.example.program6.util.HibernateUtil;

public class StudentManager {

    // INSERT
    @SuppressWarnings("deprecation")
    public void insertStudent(Student1 student) {
        try (Session session = HibernateUtil.getSession()) {
            session.beginTransaction();

            session.persist(student);

            session.getTransaction().commit();
        }
    }

    // SEARCH BY ID
    public Student1 searchStudentById(int id) {
        try (Session session = HibernateUtil.getSession()) {
            return session.get(Student1.class, id);
        }
    }

    // UPDATE
    @SuppressWarnings("deprecation")
    public void updateStudentAge(int id, int newAge) {
        try (Session session = HibernateUtil.getSession()) {
            session.beginTransaction();

            Student1 student = session.get(Student1.class, id);

            if (student != null) {
                student.setAge(newAge);
                session.merge(student);
            }

            session.getTransaction().commit();
        }
    }

    // DELETE
    @SuppressWarnings("deprecation")
    public void deleteStudent(int id) {
        try (Session session = HibernateUtil.getSession()) {
            session.beginTransaction();

            Student1 student = session.get(Student1.class, id);

            if (student != null) {
                session.remove(student);
            }

            session.getTransaction().commit();
        }
    }
}