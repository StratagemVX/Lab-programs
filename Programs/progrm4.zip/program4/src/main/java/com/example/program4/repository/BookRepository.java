package com.example.program4.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.program4.model.Book;

public interface BookRepository extends JpaRepository<Book, Long> {
}