package com.example.program5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Program5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
