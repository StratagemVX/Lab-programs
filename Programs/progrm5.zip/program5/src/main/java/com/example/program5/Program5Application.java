package com.example.program5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Program5Application {
    public static void main(String[] args) {
        SpringApplication.run(Program5Application.class, args);
    }
}