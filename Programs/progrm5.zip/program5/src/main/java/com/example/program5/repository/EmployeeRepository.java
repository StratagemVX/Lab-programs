package com.example.program5.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.program5.module.EmployeeModule;

public interface EmployeeRepository extends JpaRepository<EmployeeModule, Long> {
}